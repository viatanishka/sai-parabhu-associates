/* Supabase connection for the public site and the admin panel.
   These two values are PUBLIC by design (safe to be in a website).
   Never put the "secret" / "service_role" key or the database password here. */
window.SPA_CONFIG = {
  supabaseUrl: "https://wnxntqrdygklqdkuzpjx.supabase.co",
  supabaseKey: "sb_publishable_B0cj_UbCsMdtZiEN2cB26w_po-jf8c5",
  whatsapp: "919404295750"
};
