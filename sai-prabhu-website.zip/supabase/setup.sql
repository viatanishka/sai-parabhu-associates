-- =====================================================================
--  Sai Prabhu Associates — database setup
--  Paste this whole file into Supabase → SQL Editor → New query → Run.
--  It is safe to run more than once.
--
--  BEFORE RUNNING: change the email on the line marked  >>> ADMIN EMAIL <<<
--  to the email that will log in to the admin panel.
-- =====================================================================

-- ---------- who is allowed to edit the site ----------
create table if not exists public.admins (
  email text primary key
);

insert into public.admins (email)
values ('CHANGE-ME@example.com')            -- >>> ADMIN EMAIL <<<
on conflict do nothing;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.admins
    where lower(email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  );
$$;

-- ---------- content shown on the public site ----------
create table if not exists public.projects (
  id          bigint generated always as identity primary key,
  title       text not null,
  type        text default '',
  place       text default '',
  year        text default '',
  image_path  text,                       -- file inside the "projects" bucket
  sort        int  default 0,
  visible     boolean default true,
  created_at  timestamptz default now()
);

create table if not exists public.documents (
  id          bigint generated always as identity primary key,
  title       text not null,
  issuer      text default '',
  image_path  text,                       -- file inside the "credentials" bucket (already watermarked)
  sort        int  default 0,
  visible     boolean default true,
  created_at  timestamptz default now()
);

create table if not exists public.testimonials (
  id          bigint generated always as identity primary key,
  quote       text not null,
  name        text not null,
  project     text default '',
  sort        int  default 0,
  visible     boolean default true,
  created_at  timestamptz default now()
);

-- ---------- messages from the contact form ----------
create table if not exists public.enquiries (
  id          bigint generated always as identity primary key,
  name        text not null check (char_length(name) between 1 and 120),
  phone       text default '' check (char_length(phone) <= 30),
  service     text default '' check (char_length(service) <= 60),
  place       text default '' check (char_length(place) <= 160),
  message     text not null check (char_length(message) between 1 and 3000),
  status      text default 'new' check (status in ('new', 'contacted', 'closed')),
  created_at  timestamptz default now()
);

-- ---------- security rules ----------
alter table public.admins       enable row level security;
alter table public.projects     enable row level security;
alter table public.documents    enable row level security;
alter table public.testimonials enable row level security;
alter table public.enquiries    enable row level security;

-- admins table: only an admin can even see it
drop policy if exists "admins read own" on public.admins;
create policy "admins read own" on public.admins
  for select using (public.is_admin());

-- public content: everyone can read visible rows, only the admin can change anything
do $$
declare t text;
begin
  foreach t in array array['projects', 'documents', 'testimonials'] loop
    execute format('drop policy if exists "public read" on public.%I', t);
    execute format('create policy "public read" on public.%I for select using (visible or public.is_admin())', t);
    execute format('drop policy if exists "admin write" on public.%I', t);
    execute format('create policy "admin write" on public.%I for all using (public.is_admin()) with check (public.is_admin())', t);
  end loop;
end $$;

-- enquiries: anyone can send one, only the admin can read or update them
drop policy if exists "anyone can send" on public.enquiries;
create policy "anyone can send" on public.enquiries
  for insert to anon, authenticated with check (status = 'new');

drop policy if exists "admin reads" on public.enquiries;
create policy "admin reads" on public.enquiries
  for select using (public.is_admin());

drop policy if exists "admin updates" on public.enquiries;
create policy "admin updates" on public.enquiries
  for update using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admin deletes" on public.enquiries;
create policy "admin deletes" on public.enquiries
  for delete using (public.is_admin());

-- ---------- file storage ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('projects',    'projects',    true, 5242880, array['image/jpeg', 'image/png', 'image/webp']),
  ('credentials', 'credentials', true, 5242880, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "site images readable" on storage.objects;
create policy "site images readable" on storage.objects
  for select using (bucket_id in ('projects', 'credentials'));

drop policy if exists "admin uploads" on storage.objects;
create policy "admin uploads" on storage.objects
  for insert to authenticated with check (bucket_id in ('projects', 'credentials') and public.is_admin());

drop policy if exists "admin updates files" on storage.objects;
create policy "admin updates files" on storage.objects
  for update to authenticated using (bucket_id in ('projects', 'credentials') and public.is_admin());

drop policy if exists "admin deletes files" on storage.objects;
create policy "admin deletes files" on storage.objects
  for delete to authenticated using (bucket_id in ('projects', 'credentials') and public.is_admin());

-- Done. Next: Authentication → Users → Add user, using the same email as above.
